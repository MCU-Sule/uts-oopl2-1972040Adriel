package com.example.squiddemo.entity;

public class Hutang {
    private int Id;
    private String PemberiUtang;
    private Double Jumlah;
    private int Player_id;

    public Hutang() {
    }

    public Hutang(int id, String pemberiUtang, Double jumlah, int player_id) {
        Id = id;
        PemberiUtang = pemberiUtang;
        Jumlah = jumlah;
        Player_id = player_id;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getPemberiUtang() {
        return PemberiUtang;
    }

    public void setPemberiUtang(String pemberiUtang) {
        PemberiUtang = pemberiUtang;
    }

    public Double getJumlah() {
        return Jumlah;
    }

    public void setJumlah(Double jumlah) {
        Jumlah = jumlah;
    }

    public int getPlayer_id() {
        return Player_id;
    }

    public void setPlayer_id(int player_id) {
        Player_id = player_id;
    }

    @Override
    public String toString() {
        return "Hutang{" +
                "Id=" + Id +
                ", PemberiUtang='" + PemberiUtang + '\'' +
                ", Jumlah=" + Jumlah +
                ", Player_id=" + Player_id +
                '}';
    }
}
