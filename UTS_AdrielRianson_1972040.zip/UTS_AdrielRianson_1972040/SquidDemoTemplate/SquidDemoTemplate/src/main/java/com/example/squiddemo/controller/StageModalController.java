package com.example.squiddemo.controller;

import com.example.squiddemo.entity.Player;
import javafx.application.Platform;
import javafx.beans.property.Property;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

public class StageModalController {
    @FXML
    public TextField txtId;
    @FXML
    public TextField txtNama;
    @FXML
    public TextField txtUmur;
    @FXML
    public TextField txtKeahlian;
    @FXML
    private final Alert alert = new Alert(Alert.AlertType.ERROR);
    public void ok(ActionEvent actionEvent) {
        if (txtId.getText().isEmpty() || txtNama.getText().isEmpty()||txtUmur.getText().isEmpty()||txtKeahlian.getText().isEmpty()) {
            alert.setHeaderText("Null");
            alert.setContentText("Incomplete");
            alert.show();
        } else {
            alert.setHeaderText("Null");
            alert.setContentText("Duplicate");
            alert.show();
        }
    }
    @FXML
    public void cancel(ActionEvent actionEvent) {
        Platform.exit();
    }
}
