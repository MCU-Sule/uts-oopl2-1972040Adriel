package com.example.squiddemo.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class SquidController {
    @FXML
    public TableView tablePemain;
    @FXML
    public ComboBox cmbPeserta;
    @FXML
    public TextField txtPemberiUtang;
    @FXML
    public TextField txtJumlah;
    @FXML
    public TableView tableHutang;
    @FXML
    public TableColumn id_pemain;
    @FXML
    public TableColumn hutangterhadap;
    @FXML
    public TableColumn sejumlah;
    @FXML
    public TableColumn id;
    @FXML
    public TableColumn nama;
    @FXML
    public TableColumn umur;
    @FXML
    public TableColumn kemampuan;
    @FXML
    public void add(ActionEvent actionEvent) {
    }
    @FXML
    public void edit(ActionEvent actionEvent) {
    }
    @FXML
    public void hapus(ActionEvent actionEvent) {
        txtPemberiUtang.clear();
        txtJumlah.clear();
    }

    public void tambahdatahutang(ActionEvent actionEvent) {

    }


}
