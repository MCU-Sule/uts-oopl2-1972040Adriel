module com.example.squiddemo {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    exports com.example.squiddemo;
    exports com.example.squiddemo.controller;
}